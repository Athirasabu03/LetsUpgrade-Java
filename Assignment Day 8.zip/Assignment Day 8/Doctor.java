package com.Employee;

public class Doctor extends Employee{
    
    public void treatment(){
        System.out.System.out.println("Examine and provide required treatment");

    }
    
    public void medicine()
    {
        System.out.println("Prescribes require medicine");
    }
}