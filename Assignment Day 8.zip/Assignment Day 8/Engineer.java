package com.Employee;

public class Engineer extends Employee{
    
    public void Plan(){
        System.out.println("Plan and draw the design of the project");
    }
    public void Implementation()
    {
        System.out.println("Implement the project");
    }
}