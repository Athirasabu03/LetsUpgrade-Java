package com.Employee;
public class Pilot extends Employee{
    public void check()
    {
        System.out.println("Check if conditions are suitable for take of flight");
    }
    public void drive()
    {
        System.out.println("Fly the aeroplane to the destination");
    }
}