package com.Employee;
import java.util.Scanner;
public class Employee{
    String name;
    int age;
    double salary;
    String designation;
}
public static void main(String[] args){
 public void getDetails()
 {
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter Employee name: ");
     name=sc.next();
     System.out.println("Enter Employee age: ");
     name=sc.nextInt();
     System.out.println("Enter Employee salary: ");
     name=sc.nextInt();
     System.out.println("Enter Employee designation: ");
     name=sc.next();
 }
 public void display()
 {
     System.out.println(name+" "+age+" "+salary+" "+designation);
 }
}