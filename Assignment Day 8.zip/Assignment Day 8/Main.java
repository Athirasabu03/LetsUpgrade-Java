package com.Employee;
public class Main{
     public static void main (String[] args) {
        Employee[]e=new Employee[3];
        for(int i=0;i<3;i++)
        {
            e[i]=new Employee();
        }
        for (int i=0;i<3;i++)
        {
            e[i].getDetails();
        }
         for (int i=0;i<3;i++)
        {
            e[i].Display();
        }
        
        Doctor[]d=new Doctor();
        
        for(int i=0;i<3;i++)
        {
            d[i]=new Doctor();
        }
        for (int i=0;i<3;i++)
        {
            d[i].Treatment();
        }
         for (int i=0;i<3;i++)
        {
            d[i].Medicine();
        }
        Engineer[]e1=new Engineer();
        
        for(int i=0;i<3;i++)
        {
            e1[i]=new Engineer();
        }
        for (int i=0;i<3;i++)
        {
            e1[i].Plan();
        }
         for (int i=0;i<3;i++)
        {
            e1[i].Implementation();
        }
        
      Pilot[]p=new Pilot();
        
        for(int i=0;i<3;i++)
        {
            p[i]=new Pilot();
        }
        for (int i=0;i<3;i++)
        {
            p[i].check();
        }
         for (int i=0;i<3;i++)
        {
            p[i].drive();
        }  
    }
}