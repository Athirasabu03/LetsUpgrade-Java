package com.sum;
import java.util.Scanner;

public class Sum {

    public  void sum(){
        Scanner sc=new Scanner(System.in);
       public int[] numbers=new int[5];
       public int[] sum=new int[5];
        for(int i=0;i<5;i++){
            sum=int[0]numbers+int[1]numbers+int[2]numbers+int[3]numbers+int[4]numbers;
            System.out.println(sum);
        }
    }
}
