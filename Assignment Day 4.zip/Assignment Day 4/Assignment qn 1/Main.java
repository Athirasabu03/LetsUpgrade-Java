package com.avenger;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Avenger[]avengers=new Avenger[5];
        for(int i=0;i<5;i++)
        {
            avengers[i]= new Avenger();
        }
        for(int i=0;i<5;i++)
        {
            avengers[i].getDetails();
        }
        for(int i=0;i<5;i++)
        {
            avengers[i].displayDetails();
        }
    }
}
