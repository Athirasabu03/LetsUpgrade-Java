package com.numbers;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int[]numbers=new int[5];
        Scanner sc=new Scanner(System.in);
        for(int i=0;i<5;i++)
        {
            System.out.println("Enter the number in order");
            numbers[i]=sc.nextInt();
        }
        do{
            System.out.println("The odd numbers are: "+numbers[]);
        }while (numbers %2!=0);


    }
}
